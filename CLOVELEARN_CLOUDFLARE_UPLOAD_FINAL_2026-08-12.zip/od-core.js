/**
 * OD-CORE.JS — Operator's Deck Shared Utilities v1.0.0
 * ─────────────────────────────────────────────────────
 * Canonical implementations of repeated functions across 30+ pages.
 * Include via <script src="od-core.js"></script> in any sub-page.
 *
 * Does NOT overwrite existing globals — safe to load alongside legacy code.
 * Each function checks if it's already defined before declaring.
 *
 * Covers:
 *   - Sanitization (esc, san)
 *   - Toast notifications (showToast)
 *   - Safe localStorage (odGet, odSet, odDel, odKeys)
 *   - JSON parse safety (safeJSON)
 *   - Array/number validation (vArr, vNum)
 *   - Debounce / throttle
 *   - Navigation helpers
 *   - Storage quota reporting
 */

(function(g) {
  'use strict';

  // ── SANITIZATION ──────────────────────────────────────────────
  // HTML-escape a string. Prevents XSS in innerHTML contexts.
  if (typeof g.esc !== 'function') {
    g.esc = function(s) {
      if (typeof s !== 'string') return '';
      var d = document.createElement('div');
      d.appendChild(document.createTextNode(s));
      return d.innerHTML;
    };
  }

  // Strip HTML tags and cap length. For display-only sanitization.
  if (typeof g.san !== 'function') {
    g.san = function(s, max) {
      if (typeof s !== 'string') return '';
      return s.substring(0, max || 5000).replace(/<[^>]*>/g, '');
    };
  }

  // ── TOAST NOTIFICATIONS ───────────────────────────────────────
  if (typeof g.showToast !== 'function') {
    g.showToast = function(msg, opts) {
      opts = opts || {};
      var old = document.querySelector('.toast');
      if (old) old.remove();
      var t = document.createElement('div');
      t.className = 'toast';
      if (opts.bg) t.style.background = opts.bg;
      if (opts.color) t.style.color = opts.color;
      t.textContent = msg;
      document.body.appendChild(t);
      var dur = opts.duration || 2500;
      setTimeout(function() { if (t.parentNode) t.remove(); }, dur);
    };
  }

  // ── SAFE JSON PARSING ─────────────────────────────────────────
  // Returns fallback on any parse error. Never throws.
  if (typeof g.safeJSON !== 'function') {
    g.safeJSON = function(str, fallback) {
      if (typeof fallback === 'undefined') fallback = null;
      if (typeof str !== 'string' || !str) return fallback;
      try { return JSON.parse(str); }
      catch (e) { return fallback; }
    };
  }

  // ── ARRAY / NUMBER VALIDATORS ─────────────────────────────────
  // Validate parsed value is an array, cap length.
  if (typeof g.vArr !== 'function') {
    g.vArr = function(v, max) {
      if (!Array.isArray(v)) return [];
      return max ? v.slice(0, max) : v;
    };
  }

  // Validate parsed value is a finite number, return default otherwise.
  if (typeof g.vNum !== 'function') {
    g.vNum = function(v, def) {
      var n = Number(v);
      return isFinite(n) ? n : (typeof def === 'number' ? def : 0);
    };
  }

  // ── VAULT (IndexedDB + Web Crypto) ───────────────────────────
  var _vk = null;

  var VAULT_DB    = 'clove_vault';
  var VAULT_STORE = 'keys';
  var VAULT_KEY_ID = 'main_key';

  function openVaultDB() {
    return new Promise(function(resolve, reject) {
      var req = indexedDB.open(VAULT_DB, 1);
      req.onupgradeneeded = function(e) {
        var db = e.target.result;
        if (!db.objectStoreNames.contains(VAULT_STORE)) {
          db.createObjectStore(VAULT_STORE);
        }
      };
      req.onsuccess = function() { resolve(req.result); };
      req.onerror   = function() { reject(req.error); };
    });
  }

  function getStoredKey(db) {
    return new Promise(function(resolve, reject) {
      var tx    = db.transaction(VAULT_STORE, 'readonly');
      var store = tx.objectStore(VAULT_STORE);
      var req   = store.get(VAULT_KEY_ID);
      req.onsuccess = function() { resolve(req.result || null); };
      req.onerror   = function() { reject(req.error); };
    });
  }

  function storeKey(db, jwk) {
    return new Promise(function(resolve, reject) {
      var tx    = db.transaction(VAULT_STORE, 'readwrite');
      var store = tx.objectStore(VAULT_STORE);
      var req   = store.put(jwk, VAULT_KEY_ID);
      req.onsuccess = function() { resolve(); };
      req.onerror   = function() { reject(req.error); };
    });
  }

  function generateVaultKey() {
    return crypto.subtle.generateKey(
      { name: 'AES-GCM', length: 256 },
      true,
      ['encrypt', 'decrypt']
    );
  }

  if (typeof g.initVault !== 'function') {
    g.initVault = async function() {
      if (_vk) return _vk;

      var db  = await openVaultDB();
      var jwk = await getStoredKey(db);

      if (!jwk) {
        var key = await generateVaultKey();
        jwk = await crypto.subtle.exportKey('jwk', key);
        await storeKey(db, jwk);
        _vk = key;
        return _vk;
      }

      _vk = await crypto.subtle.importKey(
        'jwk',
        jwk,
        { name: 'AES-GCM' },
        false,
        ['encrypt', 'decrypt']
      );

      return _vk;
    };
  }

  // ── ENCRYPT / DECRYPT ────────────────────────────────────────
  function uint8ToBase64(u8) {
    var binary = '';
    for (var i = 0; i < u8.length; i++) binary += String.fromCharCode(u8[i]);
    return btoa(binary);
  }

  function base64ToUint8(b64) {
    var binary = atob(b64);
    var bytes = new Uint8Array(binary.length);
    for (var i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  g.encryptValue = async function(value) {
    if (!_vk) throw new Error('Vault not initialized');
    var iv       = crypto.getRandomValues(new Uint8Array(12));
    var encoded  = new TextEncoder().encode(JSON.stringify(value));
    var cipher   = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv }, _vk, encoded);
    var combined = new Uint8Array(12 + cipher.byteLength);
    combined.set(iv, 0);
    combined.set(new Uint8Array(cipher), 12);
    return uint8ToBase64(combined);
  };

  function _safeReviver(k, v) {
    if (k === '__proto__' || k === 'constructor' || k === 'prototype') return undefined;
    return v;
  }

  g.decryptValue = async function(stored) {
    if (!_vk) throw new Error('Vault not initialized');
    var combined  = base64ToUint8(stored);
    var iv        = combined.slice(0, 12);
    var data      = combined.slice(12);
    var decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv }, _vk, data);
    return JSON.parse(new TextDecoder().decode(decrypted), _safeReviver);
  };

  // ── SAFE LOCALSTORAGE (encrypted) ────────────────────────────
  // odGet / odSet / odDel are now async.
  // odGet: tries decrypt first; falls back to plaintext + migrates silently.
  // odSet: always encrypts before writing.
  // Never throws — callers get fallback on any failure.

  g.odGet = async function(key, fallback) {
    if (typeof fallback === 'undefined') fallback = null;
    try {
      var raw = localStorage.getItem(key);
      if (raw === null) return fallback;

      // Try encrypted path first
      try {
        return await g.decryptValue(raw);
      } catch (_e) {
        // Legacy plaintext — migrate silently
        try {
          var parsed = JSON.parse(raw, _safeReviver);
          g.odSet(key, parsed); // fire-and-forget re-encrypt
          return parsed;
        } catch (_e2) {
          return fallback;
        }
      }
    } catch (err) {
      console.error('odGet failed:', err);
      return fallback;
    }
  };

  g.odSet = async function(key, value) {
    try {
      var encrypted = await g.encryptValue(value);
      localStorage.setItem(key, encrypted);
    } catch (err) {
      if (err && err.name === 'QuotaExceededError' && typeof g.showToast === 'function') {
        g.showToast('STORAGE FULL \u2014 EXPORT YOUR DATA NOW');
      }
      console.error('odSet failed:', err);
    }
  };

  g.odDel = function(key) {
    try { localStorage.removeItem(key); } catch (err) { console.error('odDel failed:', err); }
  };

  // ── MIGRATION ─────────────────────────────────────────────────
  var MIGRATION_FLAG = 'od_migrated_v1';

  function isMigrated() {
    return localStorage.getItem(MIGRATION_FLAG) === '1';
  }

  function setMigrated() {
    localStorage.setItem(MIGRATION_FLAG, '1');
  }

  // Keys read by IntelEngine via raw localStorage — must stay plaintext
  var INTEL_KEYS = ['od_wgo_logs','od_tipp_full','od_improve_full','od_mindfulness_full',
    'od_act_v1','od_cbt_records','od_dm_v1','od_chain_analysis','od_rsd',
    'od_values_records','od_opposite_action','od_intercepts','od_redprotocol_log',
    'od_clinical_scores','od_meditation','od_aar_entries','od_protocol_logs',
    'od_protocol_hist','od_protocol_pending','od_intel_brief','od_intel_last_run','od_intel_config'];

  async function migrateLegacyKeys() {
    if (!_vk) { console.warn('Vault not initialized — skipping migration'); return; }
    var keys = Object.keys(localStorage);
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      if (key === MIGRATION_FLAG) continue;
      if (INTEL_KEYS.indexOf(key) > -1) continue;
      try {
        var raw = localStorage.getItem(key);
        if (!raw) continue;
        try { await g.decryptValue(raw); continue; } catch (_e) {} // already encrypted
        try {
          var parsed = JSON.parse(raw, _safeReviver);
          await g.odSet(key, parsed);
        } catch (_e2) {} // not JSON — leave as-is
      } catch (err) {
        console.error('Migration error on key: ' + key, err);
      }
    }
  }

  g.runMigrationOnce = async function() {
    if (isMigrated()) return;
    try {
      await migrateLegacyKeys();
      setMigrated();
    } catch (err) {
      console.error('Migration failed:', err);
    }
  };

  // ── INTEL WARM-CACHE + AT-REST ENCRYPTION FOR CRISIS KEYS ─────
  // ADR-052 local-device hygiene. Web Crypto is async but many INTEL readers are
  // sync, so we warm an in-memory cache on load and expose a synchronous intelGet()
  // with a legacy-plaintext fallback (so existing data NEVER silently vanishes) plus
  // a whenIntelReady() barrier for the one page that DISPLAYS an encrypted key.
  // ENCRYPT_KEYS is a closed, intentional list — only these are encrypted at rest.
  var ENCRYPT_KEYS = ['od_redprotocol_log', 'od_clinical_scores'];
  // Retention ceilings (keep newest). Writer ordering differs per key:
  // od_redprotocol_log entries are unshifted to the front (newest-first);
  // od_clinical_scores entries are pushed to the end (newest-last, matches
  // clinical-assessments.html's scoreTest()) — RETENTION_NEWEST_LAST records
  // which keys need the tail kept instead of the head.
  var RETENTION = { od_redprotocol_log: 200, od_clinical_scores: 500 };
  var RETENTION_NEWEST_LAST = { od_clinical_scores: true };
  var _intelCache = {};
  var _intelWarmed = false;
  var _intelReadyResolve;
  var _intelReady = (typeof Promise !== 'undefined')
    ? new Promise(function(res) { _intelReadyResolve = res; })
    : { then: function(f) { try { f(); } catch (e) {} } };

  function _isEncryptKey(key) { return ENCRYPT_KEYS.indexOf(key) > -1; }

  function _applyRetention(key, value) {
    var cap = RETENTION[key];
    if (!cap || !Array.isArray(value) || value.length <= cap) return value;
    return RETENTION_NEWEST_LAST[key] ? value.slice(-cap) : value.slice(0, cap);
  }

  // Synchronous read. Cache-first; else legacy-plaintext (always readable); else
  // fallback. Ciphertext-before-warm or corrupt storage returns fallback WITHOUT
  // deleting the raw value — data is preserved on disk, never silently destroyed.
  if (typeof g.intelGet !== 'function') {
    g.intelGet = function(key, fallback) {
      if (typeof fallback === 'undefined') fallback = null;
      if (Object.prototype.hasOwnProperty.call(_intelCache, key)) return _intelCache[key];
      try {
        var raw = localStorage.getItem(key);
        if (raw === null) return fallback;
        return JSON.parse(raw, _safeReviver);
      } catch (_e) {
        return fallback;
      }
    };
  }

  // Async write. Applies retention, updates the sync cache immediately, then persists
  // (encrypted for ENCRYPT_KEYS, plaintext otherwise or if crypto is unavailable).
  if (typeof g.intelSet !== 'function') {
    g.intelSet = async function(key, value) {
      var capped = _applyRetention(key, value);
      _intelCache[key] = capped;
      try {
        if (_isEncryptKey(key)) {
          if (!_vk) { try { await g.initVault(); } catch (_e) {} }
          if (_vk) { await g.odSet(key, capped); return capped; }
        }
        localStorage.setItem(key, JSON.stringify(capped));
      } catch (err) { console.error('intelSet failed:', key, err); }
      return capped;
    };
  }

  g.whenIntelReady = function() { return _intelReady; };
  g.isIntelWarmed = function() { return _intelWarmed; };

  // Populate the cache from disk. For ENCRYPT_KEYS: decrypt existing ciphertext, and
  // migrate any legacy plaintext → ciphertext (WITHOUT retention-trimming, to preserve
  // full history on first migration). Corrupt values are preserved (logged, skipped).
  g.warmIntelCache = async function() {
    try { await g.initVault(); } catch (_e) { /* no crypto → plaintext fallback only */ }
    for (var i = 0; i < INTEL_KEYS.length; i++) {
      var key = INTEL_KEYS[i];
      try {
        var raw = localStorage.getItem(key);
        if (raw === null) continue;
        var value = null, wasEncrypted = false;
        if (_vk) {
          try { value = await g.decryptValue(raw); wasEncrypted = true; } catch (_e) { /* plaintext */ }
        }
        if (!wasEncrypted) {
          try { value = JSON.parse(raw, _safeReviver); }
          catch (_e2) { console.error('warmIntelCache: corrupt key preserved (not deleted):', key); continue; }
          if (_isEncryptKey(key) && _vk) { try { await g.odSet(key, value); } catch (_e3) {} }
        }
        _intelCache[key] = value;
      } catch (err) { console.error('warmIntelCache error on ' + key, err); }
    }
    _intelWarmed = true;
    if (_intelReadyResolve) _intelReadyResolve();
    return _intelCache;
  };

  // Auto-warm once per load so pages that don't explicitly await still migrate/populate.
  function _autoWarmIntel() { try { g.warmIntelCache(); } catch (e) { console.error('auto warmIntelCache failed', e); } }
  if (typeof document !== 'undefined' && document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _autoWarmIntel, { once: true });
  } else {
    _autoWarmIntel();
  }

  // List all OD-related keys (od_, od3, sp-plans, ops-, pd-).
  if (typeof g.odKeys !== 'function') {
    g.odKeys = function() {
      var keys = [];
      try {
        for (var i = 0; i < localStorage.length; i++) {
          var k = localStorage.key(i);
          if (k && (
            k.indexOf('od') === 0 ||
            k.indexOf('sp-') === 0 ||
            k.indexOf('ops-') === 0 ||
            k.indexOf('pd-') === 0 ||
            k === 'kb-tasks'
          )) {
            keys.push(k);
          }
        }
      } catch (e) {}
      return keys.sort();
    };
  }

  // ── STORAGE QUOTA ─────────────────────────────────────────────
  // Estimate total bytes used by OD keys in localStorage.
  if (typeof g.odStorageSize !== 'function') {
    g.odStorageSize = function() {
      var total = 0;
      var keys = g.odKeys();
      for (var i = 0; i < keys.length; i++) {
        try {
          var v = localStorage.getItem(keys[i]);
          if (v) total += keys[i].length + v.length;
        } catch (e) {}
      }
      return total * 2; // UTF-16 = 2 bytes per char
    };
  }

  // ── DEBOUNCE / THROTTLE ───────────────────────────────────────
  if (typeof g.odDebounce !== 'function') {
    g.odDebounce = function(fn, ms) {
      var t;
      return function() {
        var ctx = this, args = arguments;
        clearTimeout(t);
        t = setTimeout(function() { fn.apply(ctx, args); }, ms);
      };
    };
  }

  if (typeof g.odThrottle !== 'function') {
    g.odThrottle = function(fn, ms) {
      var last = 0;
      return function() {
        var now = Date.now();
        if (now - last >= ms) {
          last = now;
          fn.apply(this, arguments);
        }
      };
    };
  }

  // ── NAVIGATION HELPERS ────────────────────────────────────────
  // Canonical back-to-deck navigation.
  if (typeof g.odBack !== 'function') {
    g.odBack = function() {
      window.location.href = './deck.html?tab=tools';
    };
  }

  // Navigate to a sub-page with optional disclaimer gate.
  if (typeof g.odNav !== 'function') {
    g.odNav = function(href) {
      window.location.href = href;
    };
  }

  // ── DATE HELPERS ──────────────────────────────────────────────
  if (typeof g.odDate !== 'function') {
    g.odDate = function(d) {
      if (!d) d = new Date();
      if (typeof d === 'string') d = new Date(d);
      var m = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      return m[d.getMonth()] + ' ' + d.getDate() + ', ' + d.getFullYear();
    };
  }

  if (typeof g.odTimestamp !== 'function') {
    g.odTimestamp = function() {
      return new Date().toISOString();
    };
  }

  // ── PERFORMANCE: requestAnimationFrame render batching ────────
  if (typeof g.odRender !== 'function') {
    var pending = false;
    g.odRender = function(fn) {
      if (pending) return;
      pending = true;
      requestAnimationFrame(function() {
        pending = false;
        fn();
      });
    };
  }

  // ── INTEGRITY CHECK ───────────────────────────────────────────
  // Validate a localStorage key contains parseable JSON. Returns status object.
  if (typeof g.odCheckKey !== 'function') {
    g.odCheckKey = function(key) {
      var result = { key: key, exists: false, valid: false, size: 0, type: 'missing' };
      try {
        var raw = localStorage.getItem(key);
        if (raw === null) return result;
        result.exists = true;
        result.size = (key.length + raw.length) * 2;
        var parsed = JSON.parse(raw);
        result.valid = true;
        result.type = Array.isArray(parsed) ? 'array[' + parsed.length + ']' :
                      (parsed && typeof parsed === 'object') ? 'object' :
                      typeof parsed;
      } catch (e) {
        result.type = 'CORRUPT';
      }
      return result;
    };
  }

  // ── HELP BUTTON ───────────────────────────────────────────────
  // Injects a persistent crisis shortcut on every page except red-protocol.
  // Auto-runs on load; safe to call again (ID guard prevents duplicates).
  var HELP_ID = 'clove-help-btn';

  function injectHelpButton() {
    try {
      if (document.getElementById(HELP_ID)) return;
      var path = (location.pathname || '').toLowerCase();
      if (path.indexOf('red-protocol') > -1) return;
      var btn = document.createElement('button');
      btn.id = HELP_ID;
      btn.textContent = 'HELP';
      btn.setAttribute('aria-label', 'Crisis help — tap for immediate support');
      btn.style.position = 'fixed';
      btn.style.right = '16px';
      btn.style.bottom = '72px';
      btn.style.zIndex = '9999';
      btn.style.minWidth = '44px';
      btn.style.height = '44px';
      btn.style.padding = '0 10px';
      btn.style.border = 'none';
      btn.style.borderRadius = '10px';
      btn.style.background = 'var(--red, #c0392b)';
      btn.style.color = '#fff';
      btn.style.fontFamily = 'DM Mono, monospace';
      btn.style.fontSize = '10px';
      btn.style.letterSpacing = '0.08em';
      btn.style.cursor = 'pointer';
      btn.style.boxShadow = '0 6px 18px rgba(0,0,0,0.35)';
      btn.style.webkitTapHighlightColor = 'transparent';
      btn.onclick = function() { location.href = '/red-protocol.html'; };
      document.body.appendChild(btn);
    } catch (err) {
      console.error('HELP button injection failed:', err);
    }
  }

  g.injectHelpButton = injectHelpButton;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectHelpButton, { once: true });
  } else {
    injectHelpButton();
  }

  // ── VERSION STAMP ─────────────────────────────────────────────
  g.OD_CORE_VERSION = '1.0.0';

})(typeof window !== 'undefined' ? window : this);
