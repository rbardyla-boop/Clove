/**
 * Neon Circuit — City Block append-only world event log (Phase 4C), PURE.
 *
 * A bounded, append-only log of SERVER-AUTHORED, public-safe city facts (joins,
 * leaves, portal request/accept/reject, arcade-interior open/close). It is the first
 * durable-feeling living-world primitive and the seam future phases read from
 * (4D Hive Scheduler, 4E Host Rank) — WITHOUT any of those being built here.
 *
 * Authority: the SERVER authors every event. This module never reads a client-
 * supplied event id, sequence, or timestamp — `appendCityEvent` assigns all three
 * itself. Payloads are filtered to a public-safe allowlist, so no private/economy
 * data (balance, ledger, inventory, admin, raw connection ids) can ever ride an
 * event. Isolated from the arcade economy feed (workers/arcade/src/events.mjs).
 *
 * Imported by the CityRoom DO, the city dev shim, the unit tests, and the browser.
 */
import { SCHEMA_VERSION } from './city-block.mjs';

/** Keep the log bounded so per-room state stays small. */
export const MAX_CITY_EVENTS = 50;

/** Server-authored city event types. 4C = discrete world facts (no per-move logging);
 *  4D adds the two Hive-Scheduler pressure events; 4E adds host-rank events; 4F adds
 *  the constrained block-stewardship events (preview/apply/reject/reset). */
export const EVENT_TYPES = Object.freeze([
  'city_player_joined',
  'city_player_left',
  'city_portal_enter_requested',
  'city_portal_enter_accepted',
  'city_portal_enter_rejected',
  'city_arcade_interior_opened',
  'city_arcade_interior_closed',
  // Phase 4D — Hive Scheduler (non-authoritative, display-only pressure):
  'city_scheduler_tick',
  'city_pressure_suggested',
  // Phase 4E — Host Rank (non-cash, display-only block reputation):
  'city_host_rank_evaluated',
  'city_host_rank_changed',
  // Phase 4F — Block Stewardship (constrained, reversible, non-cash visual edits):
  'city_stewardship_previewed',
  'city_stewardship_applied',
  'city_stewardship_rejected',
  'city_stewardship_reset',
  // Phase 4G — Instanced, non-destructive Block Trial (Signal Grid; ephemeral, non-cash):
  'city_block_trial_requested',
  'city_block_trial_started',
  'city_block_trial_joined',
  'city_block_trial_updated',
  'city_block_trial_completed',
  'city_block_trial_rejected',
  'city_block_trial_closed',
  // Phase 7C — Activity objectives WITHOUT rewards (server-evaluated acknowledgment only):
  'city_objective_completed',
]);
const TYPE_SET = new Set(EVENT_TYPES);
export function isCityEventType(t) { return TYPE_SET.has(t); }

/** Public-safe scalar payload fields. Anything else is dropped.
 *  (4D adds pressure/severity; 4E adds tier/support_signal/score/score_cap;
 *   4F adds the stewardship visual tokens palette/sign_variant/intensity;
 *   4G adds the trial scalars instance_id/objective/status/node_count/stabilized_count/duration_ms;
 *   7C adds the objective acknowledgment scalars objective_id/kind/ack/count.) */
const ALLOWED_PAYLOAD_KEYS = ['portalId', 'target', 'reason', 'pressure', 'severity', 'tier', 'support_signal', 'score', 'score_cap', 'palette', 'sign_variant', 'intensity', 'instance_id', 'objective', 'status', 'node_count', 'stabilized_count', 'duration_ms', 'objective_id', 'kind', 'ack', 'count'];
/** Cap allowlisted string values so a crafted client field can't bloat storage/broadcasts. */
const MAX_PAYLOAD_STR = 64;

/** PURE: keep only allowlisted public-safe scalars (strings length-capped) — never private/economy data. */
export function sanitizeEventPayload(payload) {
  const out = {};
  if (!payload || typeof payload !== 'object') return out;
  for (const k of ALLOWED_PAYLOAD_KEYS) {
    const v = payload[k];
    if (typeof v === 'string') { if (v.length <= MAX_PAYLOAD_STR) out[k] = v; }
    else if (typeof v === 'number') { if (Number.isFinite(v)) out[k] = v; } // drop NaN/Infinity defensively
    else if (typeof v === 'boolean') out[k] = v;
  }
  return out;
}

/** A fresh, empty append-only log. `seq` is monotonic and survives FIFO pruning. */
export function createEventLog() {
  return { events: [], seq: 0 };
}

/**
 * Append a SERVER-AUTHORED public-safe event. The server assigns the id, seq, and
 * timestamp — any client-supplied id/seq/server_time in `fields` is ignored. Returns
 * { log, event } (new log; old events are never mutated). Trims to MAX_CITY_EVENTS
 * (FIFO) while keeping `seq` monotonic, so event ids stay unique across pruning.
 */
export function appendCityEvent(log, fields = {}) {
  const base = (log && Array.isArray(log.events)) ? log : createEventLog();
  const { type, cityId, actorPublicId = null, payload = {}, now = Date.now() } = fields;
  const safeCity = (typeof cityId === 'string' && cityId) ? cityId : 'city'; // ids stay well-formed
  const seq = (Number.isFinite(base.seq) ? base.seq : 0) + 1;
  const safeType = isCityEventType(type) ? type : 'city_unknown'; // never trust an arbitrary type
  const event = Object.freeze({
    schema_version: SCHEMA_VERSION,
    event_id: `${safeCity}:${seq}:${safeType}`,
    seq,
    city_id: safeCity,
    type: safeType,
    server_time: now,
    actor_public_id: (typeof actorPublicId === 'string' && actorPublicId) ? actorPublicId : null,
    payload: sanitizeEventPayload(payload),
    public_safe: true,
  });
  const events = [...base.events, event];
  while (events.length > MAX_CITY_EVENTS) events.shift();
  return { log: { events, seq }, event };
}

/** The most recent `limit` events (bounded by MAX_CITY_EVENTS). */
export function recentEvents(log, limit = MAX_CITY_EVENTS) {
  const evs = (log && Array.isArray(log.events)) ? log.events : [];
  const n = Math.max(0, Math.min(Number(limit) || MAX_CITY_EVENTS, MAX_CITY_EVENTS));
  return evs.slice(-n);
}

/** Public-safe wire payload of recent events (carries the protocol schema version). */
export function cityEventsPayload(log, limit = MAX_CITY_EVENTS) {
  return { schema_version: SCHEMA_VERSION, events: recentEvents(log, limit) };
}
