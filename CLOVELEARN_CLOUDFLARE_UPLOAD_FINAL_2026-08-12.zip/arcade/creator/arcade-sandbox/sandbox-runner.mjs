/**
 * Creator Foundation CF-4 — LOCAL arcade sandbox runner (trusted host).
 *
 * Imports + vets a package (import-arcade-package.mjs), then runs it in a HARDENED, ISOLATED iframe:
 *   - sandbox="allow-scripts" only  → the frame is a NULL origin: no storage, no cookies, no
 *     same-origin access to this page, no top-navigation, no forms, no popups;
 *   - a strict CSP (default-src 'none'; NO connect-src → NO network of any kind; NO 'unsafe-eval'
 *     → eval/new Function blocked at runtime; img-src data: only → no external assets);
 *   - the package game+adapter source is inlined as ONE module (the importer guarantees the entry has
 *     no imports and the adapter imports only ./game.mjs, so concatenation is sound; the importer also
 *     rejects </script> + markup, so inlining is safe);
 *   - the ONLY host↔frame channel is a narrow postMessage frame contract (input in, result out).
 *
 * The host NEVER trusts the frame: a proposed result is surfaced as an UNTRUSTED LOCAL PROPOSAL with
 * `server_authorized:false`. No live cabinet registration, no ticket/prize/ledger authority, no network
 * from the frame. Local creator tooling only.
 */
import { importArcadePackage } from '../arcade-importer/import-arcade-package.mjs';
import { packageHash } from '../validator/package-hash.mjs';
// Creator Freedom v1 — LOCAL-ONLY play retention (host page; never the sandbox iframe). Records best
// score / grade / plays by local package fingerprint in localStorage. No server, no account, no economy.
import { readStore, writeStore, recordResult, getStats } from './free-sandbox-retention.mjs';

const SAMPLE_DIR = '../samples/arcade-sample/';

// One-click playtest handoff: the SAME-ORIGIN sessionStorage key the arcade-builder writes its gated
// build to. We read it ONCE on load, clear it immediately, and run it through the normal run() gate
// (importArcadePackage + null-origin iframe) — identical isolation to a manual import. Treated as
// UNTRUSTED boundary input: parsed defensively, ignored on any malformed shape. Keep this literal
// identical to HANDOFF_KEY in arcade-builder/arcade-builder.mjs (a node test asserts they match).
const HANDOFF_KEY = 'cf_builder_sandbox_handoff_v1';

// CR1D — LOCAL share code import. A creator can paste a NCLOCAL1:<base64({manifest,files})> code (or a raw
// {manifest,files} / .builder.json) from ANOTHER browser. We decode the DATA only, shape-validate it, and
// route it through the EXISTING run() gate (importArcadePackage + null-origin iframe). builder_params are
// NEVER trusted as executable state. Keep SHARE_PREFIX identical to the builder encoder (a node test asserts).
const SHARE_PREFIX = 'NCLOCAL1:';
const SHARE_CODE_MAX_CHARS = 200000; // reject oversized text before decoding (the importer re-checks 64 KiB)

let fpSeq = 0; // guards async fingerprint writes

let currentFrame = null; // the active sandbox iframe
let currentWrap = null;  // the frame's wrapper (holds the iframe + the pointer-input overlay)

const state = {
  lastReport: null,
  ready: false,
  lastProposal: null,
  frameDims: null,
  lastManifest: null, // kept so "Restart" can re-run the same package
  lastFiles: null,
  lastFingerprint: null, // local package fingerprint of the running package (for play retention)
};

function el(id) { return document.getElementById(id); }
function setStatus(text, cls) {
  const s = el('sandboxStatus');
  if (s) { s.textContent = text; s.className = 'status ' + (cls || ''); }
}
/** Presentation only: show which cabinet is being playtested. */
function setNowPlaying(manifest) {
  const n = el('nowPlaying');
  if (n) n.textContent = (manifest && (manifest.display_name || manifest.package_id)) || 'Your cabinet';
}

/** Show the LOCAL package fingerprint (sha256 of canonical {manifest,files}) so two people can confirm the
 *  same local build. NOT proof of ownership, a token, a receipt, or approval. Async, race-guarded. */
function showFingerprint(pkg) {
  const h = el('importHash');
  if (!h) return;
  if (!pkg) { h.textContent = '—'; state.lastFingerprint = null; return; }
  const seq = ++fpSeq;
  h.textContent = '…';
  packageHash({ manifest: pkg.manifest, files: pkg.files }).then(
    (v) => { if (seq === fpSeq) { h.textContent = v; state.lastFingerprint = v; } },
    () => { if (seq === fpSeq) h.textContent = '(unavailable)'; },
  );
}

/**
 * LOCAL-ONLY play retention: record a result PROPOSAL against the running package's local fingerprint
 * (best score / personal grade / play count). Host page localStorage only — the sandbox iframe never
 * touches storage; this grants no authority (every score is an untrusted local self-report). Degrades to
 * a no-op if storage is blocked or the fingerprint is not yet known.
 */
function recordPlay(proposal) {
  if (!proposal || !state.lastFingerprint || !state.lastManifest) return;
  let storage = null;
  try { storage = window.localStorage; } catch { return; }
  if (!storage) return;
  const name = state.lastManifest.display_name || state.lastManifest.package_id || 'cabinet';
  const out = recordResult(readStore(storage), {
    fp: state.lastFingerprint, name,
    score: Number(proposal.proposed_score) || 0,
    seed: Number(proposal.seed) || 0,
    won: !!proposal.won,
  });
  writeStore(storage, out.state);
  renderStats(getStats(out.state, state.lastFingerprint), out.grade, out.is_best);
}

/** Render the retention line with safe DOM nodes (no innerHTML; values are numbers/closed grades). */
function renderStats(stats, grade, isBest) {
  const box = el('fsStats');
  if (!box || !stats) return;
  box.textContent = '';
  box.hidden = false;
  const chip = (label, value, cls) => {
    const s = document.createElement('span');
    if (cls) s.className = cls;
    s.appendChild(document.createTextNode(label));
    const b = document.createElement('b');
    b.textContent = String(value);
    s.appendChild(b);
    return s;
  };
  box.appendChild(chip('grade ', grade, 'grade'));
  box.appendChild(chip('best ', stats.best));
  box.appendChild(chip('plays ', stats.plays));
  if (isBest && stats.plays > 1) { const nb = document.createElement('span'); nb.className = 'grade'; nb.textContent = 'new best!'; box.appendChild(nb); }
}

/** Strip the adapter's `import {...} from './game.mjs';` (multiline-tolerant) — createGame is
 *  concatenated in scope. The importer already guarantees the adapter's only import is './game.mjs'. */
function stripGameImport(adapterSource) {
  return adapterSource.replace(/import\s*\{[\s\S]*?\}\s*from\s*['"]\.\/game\.mjs['"]\s*;?/g, '');
}

function buildSrcdoc(gameSource, adapterSource, dims) {
  const adapter = stripGameImport(adapterSource);
  // NOTE: built by concatenation (not a template literal) so package backticks cannot break it.
  return [
    '<!doctype html><html><head><meta charset="utf-8">',
    '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; img-src data:; style-src \'unsafe-inline\'; script-src \'unsafe-inline\'">',
    '<style>html,body{margin:0;background:#05060c}canvas{display:block;width:100%;height:100%}</style></head>',
    '<body><canvas id="stage" width="' + dims.width + '" height="' + dims.height + '"></canvas>',
    '<script type="module">',
    gameSource,
    '\n',
    adapter,
    '\n',
    'const __ctx = document.getElementById("stage").getContext("2d");',
    'const __adapter = createAdapter();',
    'try { __adapter.mount({ width: ' + dims.width + ', height: ' + dims.height + ' }); } catch (e) {}',
    'let __last = 0;',
    'function __loop(ts){ const dt = __last ? Math.min((ts - __last) / 1000, 0.05) : 0; __last = ts; try { __adapter.frame(dt, __ctx); } catch (e) {} requestAnimationFrame(__loop); }',
    'requestAnimationFrame(__loop);',
    'addEventListener("message", function (e) {',
    '  if (e.source !== parent) return;', // only accept the host channel
    '  const m = e.data || {};',
    '  if (m.type === "input") { try { __adapter.input(m.event); } catch (e2) {} }',
    '  else if (m.type === "request_result") {',
    '    let r = null; try { r = __adapter.result(); } catch (e3) { r = null; }',
    '    parent.postMessage({ type: "result_proposal", proposal: r, trust: "untrusted_local_proposal", server_authorized: false }, "*");',
    '  }',
    '});',
    'parent.postMessage({ type: "sandbox_ready" }, "*");',
    '</' + 'script></body></html>',
  ].join('\n');
}

function teardown() {
  if (currentWrap && currentWrap.parentNode) currentWrap.parentNode.removeChild(currentWrap);
  currentWrap = null;
  currentFrame = null;
  state.ready = false;
  state.lastProposal = null;
}

/** Import + vet a package and (if ok) run it in the hardened sandbox. Returns the import report. */
export function run(manifest, files) {
  teardown();
  const st = el('fsStats'); if (st) { st.hidden = true; st.textContent = ''; } // clear prior package's retention line
  const report = importArcadePackage({ manifest, files });
  state.lastReport = report;
  const reportEl = el('sandboxReport');
  if (reportEl) reportEl.textContent = report.ok ? 'IMPORT OK — running in local sandbox (untrusted)' : ('BLOCKED:\n' + report.errors.join('\n'));
  if (!report.ok) { setStatus('BLOCKED — package rejected', 'sb-bad'); showFingerprint(null); return report; }

  state.lastManifest = manifest; state.lastFiles = files; // remembered so "Restart" can re-run this package
  setNowPlaying(manifest);
  showFingerprint({ manifest, files }); // CR1D: local fingerprint for every load path (handoff/sample/paste/restart)
  const dims = report.frame_dims || { width: 360, height: 640 };
  state.frameDims = dims;
  const host = el('sandboxMount');
  const frame = document.createElement('iframe');
  frame.setAttribute('sandbox', 'allow-scripts'); // null origin: no storage/same-origin/nav/popups
  frame.setAttribute('title', 'arcade package sandbox (local, untrusted)');
  frame.width = String(dims.width);
  frame.height = String(dims.height);
  frame.style.border = '0';
  frame.style.background = '#05060c';
  frame.style.display = 'block';
  frame.srcdoc = buildSrcdoc(files[report.entry], files[report.adapter], dims);

  // Wrap the frame with a transparent input overlay so REAL gestures (tap/hold/release/swipe/drag) over
  // the cabinet are forwarded to the game — not just a single Tap button. The overlay lives in THIS page
  // and forwards via the same postMessage input channel; the frame stays a null-origin sandbox.
  const wrap = document.createElement('div');
  wrap.className = 'sb-frame-wrap';
  wrap.style.cssText = 'position:relative;display:block;width:' + dims.width + 'px;height:' + dims.height + 'px;';
  const overlay = document.createElement('div');
  overlay.className = 'sb-input-overlay';
  overlay.setAttribute('aria-hidden', 'true');
  overlay.style.cssText = 'position:absolute;inset:0;touch-action:none;cursor:crosshair;background:transparent;';
  wireOverlay(overlay, frame, dims);
  wrap.appendChild(frame);
  wrap.appendChild(overlay);
  if (host) { host.innerHTML = ''; host.appendChild(wrap); fitFrame(host, wrap, dims); }
  currentFrame = frame;
  currentWrap = wrap;
  setStatus('running (local sandbox — results untrusted)', 'sb-run');
  return report;
}

/** Scale the native-size cabinet down to fit the available width (handles 360×640 / 640×360 / 480×480
 *  frame contracts + small screens). The WRAP becomes the scaled-size box (so the mount can center it
 *  with no overflow); the iframe stays native dims and is transform-scaled to fill it. The overlay covers
 *  the wrap, and frame.getBoundingClientRect() reflects the scale → coordinate mapping stays correct. */
function fitFrame(host, wrap, dims) {
  if (!host || !wrap) return;
  const avail = host.clientWidth || (host.parentElement && host.parentElement.clientWidth) || dims.width;
  const scale = Math.min(1, avail / dims.width);
  wrap.style.width = (dims.width * scale) + 'px';
  wrap.style.height = (dims.height * scale) + 'px';
  const frame = wrap.querySelector('iframe');
  if (frame) {
    frame.style.transformOrigin = 'top left';
    frame.style.transform = scale < 1 ? 'scale(' + scale + ')' : 'none';
  }
}

/** Forward REAL pointer gestures over the cabinet to the game as press/move/release with frame-space
 *  coordinates, so every input mode is playable (tap_window/hold_band/release_timing/swipe_lane/drag_track).
 *  Uses the SAME postMessage input channel as the Tap button — no new capability, the iframe stays
 *  null-origin with no network. */
function wireOverlay(overlay, frame, dims) {
  let down = false;
  const xy = (e) => {
    const r = frame.getBoundingClientRect();
    const sx = r.width ? (e.clientX - r.left) / r.width * dims.width : dims.width / 2;
    const sy = r.height ? (e.clientY - r.top) / r.height * dims.height : dims.height / 2;
    return { x: Math.max(0, Math.min(dims.width, sx)), y: Math.max(0, Math.min(dims.height, sy)) };
  };
  overlay.addEventListener('pointerdown', (e) => {
    down = true; try { overlay.setPointerCapture(e.pointerId); } catch { /* capture optional */ }
    const p = xy(e); sendInput({ type: 'press', x: p.x, y: p.y }); e.preventDefault();
  });
  overlay.addEventListener('pointermove', (e) => { if (!down) return; const p = xy(e); sendInput({ type: 'move', x: p.x, y: p.y }); });
  const up = (e) => { if (!down) return; down = false; const p = xy(e); sendInput({ type: 'release', x: p.x, y: p.y }); };
  overlay.addEventListener('pointerup', up);
  overlay.addEventListener('pointercancel', up);
}

/** Fetch the bundled sample package (same-origin local files; the FRAME still has no network). */
export async function loadSample() {
  const base = new URL(SAMPLE_DIR, import.meta.url);
  const [manifestText, game, adapter] = await Promise.all([
    fetch(new URL('manifest.json', base)).then((r) => r.text()),
    fetch(new URL('game.mjs', base)).then((r) => r.text()),
    fetch(new URL('adapter.mjs', base)).then((r) => r.text()),
  ]);
  const manifest = JSON.parse(manifestText);
  const files = { 'manifest.json': manifestText, [manifest.entry]: game, [manifest.adapter]: adapter };
  return { manifest, files };
}

/** UTF-8-safe base64 decode (mirror of the builder encoder). */
function fromBase64Utf8(b64) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}

/**
 * Parse UNTRUSTED shared text into {manifest, files}, or throw a friendly Error. PURE — it never runs or
 * trusts anything (run()/importArcadePackage is the real gate). Accepts:
 *   - NCLOCAL1:<base64(JSON {manifest,files})>  (the local share code),
 *   - raw {manifest,files} JSON, or a .builder.json bundle (manifest/files taken; builder_params IGNORED —
 *     builder settings are NOT executable state).
 */
export function parseSharedText(text) {
  const t = String(text == null ? '' : text).trim();
  if (!t) throw new Error('Paste a share code or package JSON first.');
  if (t.length > SHARE_CODE_MAX_CHARS) throw new Error('That input is too large to be a local cabinet.');
  let json;
  if (t.slice(0, SHARE_PREFIX.length) === SHARE_PREFIX) {
    let decoded;
    try { decoded = fromBase64Utf8(t.slice(SHARE_PREFIX.length)); } catch { throw new Error('This NCLOCAL1 share code is corrupted (bad encoding).'); }
    try { json = JSON.parse(decoded); } catch { throw new Error('This NCLOCAL1 share code is corrupted (bad data).'); }
  } else {
    try { json = JSON.parse(t); } catch { throw new Error('Not a valid share code or package JSON.'); }
  }
  if (!json || typeof json !== 'object') throw new Error('Shared data is not a package.');
  const manifest = json.manifest;
  const files = json.files;
  if (!manifest || typeof manifest !== 'object' || !files || typeof files !== 'object') {
    throw new Error('No usable manifest/files in that data — builder settings alone cannot be played here.');
  }
  return { manifest, files };
}

/** Decode + shape-validate UNTRUSTED shared text, then run it through the normal gate. Rejects malformed
 *  input with a readable message BEFORE any run. Returns true only if the package gated + ran. */
export function importSharedText(text) {
  const errEl = el('importError');
  if (errEl) { errEl.textContent = ''; errEl.hidden = true; }
  let pkg;
  try { pkg = parseSharedText(text); }
  catch (e) {
    if (errEl) { errEl.textContent = e.message; errEl.hidden = false; }
    setStatus('import rejected', 'sb-bad');
    return false;
  }
  const out = el('sandboxResult');
  if (out) out.textContent = '(none yet — play a round, then press “Finish & score”)';
  setStatus('imported a shared cabinet — gating + running locally (untrusted)', 'sb-run');
  const report = run(pkg.manifest, pkg.files); // re-gates via importArcadePackage; runs in the null-origin iframe
  if (!report.ok && errEl) { errEl.textContent = 'This cabinet was blocked by the importer — see Technical details below.'; errEl.hidden = false; }
  return report.ok;
}

function sendInput(event) { if (currentFrame && currentFrame.contentWindow) currentFrame.contentWindow.postMessage({ type: 'input', event }, '*'); }
function requestResult() { if (currentFrame && currentFrame.contentWindow) currentFrame.contentWindow.postMessage({ type: 'request_result' }, '*'); }

// host receives ONLY from the active frame; origin is null (sandbox) so we verify by source identity.
window.addEventListener('message', (e) => {
  if (!currentFrame || e.source !== currentFrame.contentWindow) return;
  const m = e.data || {};
  if (m.type === 'sandbox_ready') { state.ready = true; setStatus('ready (local sandbox)', 'sb-run'); }
  else if (m.type === 'result_proposal') {
    state.lastProposal = m;
    const out = el('sandboxResult');
    if (out) out.textContent = 'UNTRUSTED LOCAL PROPOSAL (not server-authorized): ' + JSON.stringify(m.proposal);
    recordPlay(m.proposal); // LOCAL-ONLY play retention by fingerprint (best/grade/plays)
  }
});

// Keep the cabinet fitted to the viewport (orientation change / resize).
window.addEventListener('resize', () => { if (currentWrap && state.frameDims) fitFrame(el('sandboxMount'), currentWrap, state.frameDims); });

/**
 * One-click playtest: if the builder handed off a gated build via same-origin sessionStorage, read it
 * ONCE, clear it, and run it through the normal gate. UNTRUSTED boundary input — parsed in try/catch,
 * shape-validated, ignored on anything malformed (run()/importArcadePackage is the real gate). Returns
 * true if a handoff was consumed; a plain sandbox visit with no handoff stays idle as before.
 */
export function consumeBuilderHandoff() {
  let raw = null;
  try { raw = sessionStorage.getItem(HANDOFF_KEY); } catch { return false; }
  if (!raw) return false;
  try { sessionStorage.removeItem(HANDOFF_KEY); } catch { /* best-effort clear; the run still gates */ }
  let payload = null;
  try { payload = JSON.parse(raw); } catch { return false; }
  if (!payload || typeof payload !== 'object') return false;
  const { manifest, files } = payload;
  if (!manifest || typeof manifest !== 'object' || !files || typeof files !== 'object') return false;
  setStatus('loaded from builder — gating + running locally (untrusted)', 'sb-run');
  run(manifest, files); // re-gates via importArcadePackage, then runs in the null-origin iframe
  return true;
}

// wire the page controls + expose a test/automation hook
function wire() {
  el('runSampleBtn')?.addEventListener('click', async () => { const p = await loadSample(); run(p.manifest, p.files); });
  el('tapBtn')?.addEventListener('click', () => sendInput({ type: 'tap' }));
  el('resultBtn')?.addEventListener('click', () => requestResult());
  // Restart: re-run the same package from scratch (no-op until something has been loaded).
  el('restartBtn')?.addEventListener('click', () => { if (state.lastManifest && state.lastFiles) run(state.lastManifest, state.lastFiles); });
  // CR1D: import a LOCAL share code / package by paste or file (decoded, shape-validated, then re-gated by run()).
  el('importCodeBtn')?.addEventListener('click', () => importSharedText(el('importCode')?.value || ''));
  el('importFile')?.addEventListener('change', async (e) => {
    const f = e.target.files && e.target.files[0]; if (!f) return;
    let text = '';
    try { text = await f.text(); } catch { text = ''; }
    if (el('importCode')) el('importCode').value = text;
    importSharedText(text);
    e.target.value = ''; // allow re-importing the same file
  });
  consumeBuilderHandoff(); // one-click playtest: auto-load a build handed off from the arcade-builder
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire); else wire();

// Test/automation hook — NOT part of the user path (the page buttons drive everything via wire()).
// Exposed only on local dev hosts or with ?__debug=1 so it is never a public global entrypoint once
// this surface ships in the curated upload. The real import/play flow uses the on-page buttons.
function debugHookAllowed() {
  try {
    const h = location.hostname;
    return h === 'localhost' || h === '127.0.0.1' || h === '[::1]' || h === '' ||
      location.protocol === 'file:' || /[?&]__debug=1\b/.test(location.search);
  } catch { return false; }
}
if (debugHookAllowed()) {
  window.__cf4_sandbox = {
    get lastReport() { return state.lastReport; },
    get ready() { return state.ready; },
    get lastProposal() { return state.lastProposal; },
    get frameDims() { return state.frameDims; },
    run, loadSample, sendTap: () => sendInput({ type: 'tap' }), requestResult, teardown,
    async loadSampleAndRun() { const p = await loadSample(); return run(p.manifest, p.files); },
  };
}
