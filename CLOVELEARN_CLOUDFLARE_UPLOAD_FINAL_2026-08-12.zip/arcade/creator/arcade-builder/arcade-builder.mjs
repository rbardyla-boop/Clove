/**
 * Creator Foundation — LOCAL Arcade Builder (cabinet composer; trusted, offline).
 *
 * The assembled-builder UX over the EXISTING CF pipeline. The generation core (closed token
 * tables, 14 procedural variants, the 16-starter library) lives DOM-free in
 * cabinet-templates.mjs so node tests prove every starter through the importer; this page is
 * only the picker + controls + gate report + export shell around it.
 *
 * DATA-ONLY by design: this page NEVER executes the generated game (no eval, no dynamic
 * import) — running creator code is the arcade-sandbox's job (srcdoc iframe + closed CSP).
 * All substitution values come from CLOSED token tables, and the importer's scan re-checks
 * the output regardless. No submit, no upload, no live registration.
 * See arcade/virtual-arcade/HIVE_WORLD_ALIGNMENT.md §5.
 */
import { importArcadePackage, FRAME_CONTRACT_DIMS } from '../arcade-importer/import-arcade-package.mjs';
import { packageHash } from '../validator/package-hash.mjs';
import { FRAME_CONTRACTS, SIZE_BUDGET_MIN_BYTES, SIZE_BUDGET_MAX_BYTES } from '../schemas/arcade-game-package-schema.mjs';
import { explainIssues } from '../validator/issue-explainer.mjs'; // throughput: friendly hints (explanatory only — importer stays the gate)
import {
  ACCENTS, SPEEDS, DIFFICULTY, MOTION, JUICE, INPUT_MODES, INPUT_MODE_COPY, VARIANTS, STARTERS,
  getStarter, startersByCategory, buildPackage,
} from './cabinet-templates.mjs';
import {
  COMBO_CAPS,
  CONTRAST,
  defaultReactionLaneGraph,
  DIFFICULTY_RAMPS,
  HIT_WINDOW_MS,
  LANE_COUNTS,
  MISS_LIMITS,
  MOBILE_CONTROLS,
  PARTICLE_EFFECTS,
  SCREEN_SHAKE,
  SPAWN_CADENCE_MS,
  TARGET_COUNTS,
  buildReactionLanePackage,
} from './rule-graph-templates.mjs';
import { mountFreeSandboxEditor } from './free-sandbox-editor.mjs';

const el = (id) => document.getElementById(id);

// One-click playtest handoff: the SAME-ORIGIN sessionStorage key the arcade-sandbox reads on load.
// Carries ONLY the gated build {manifest, files} so the sandbox can run it without a manual file
// export/import. The sandbox re-gates with importArcadePackage and runs in its null-origin iframe —
// this is a data handoff, not a trust transfer. Keep this literal identical to HANDOFF_KEY in
// arcade-sandbox/sandbox-runner.mjs (a node test asserts they match).
const HANDOFF_KEY = 'cf_builder_sandbox_handoff_v1';

// CR1D — LOCAL share code: a self-contained text encoding of the gated {manifest, files} so a creator can
// hand a cabinet to ANOTHER browser without any server/upload/account. It is a LOCAL package share code —
// NOT a link, token, or proof of ownership. The sandbox decodes it and re-gates through importArcadePackage;
// the builder only ENCODES data (it never runs the game). Keep SHARE_PREFIX identical to the sandbox decoder
// (a node test asserts they match).
const SHARE_PREFIX = 'NCLOCAL1:';
const SHARE_CODE_MAX_CHARS = 200000; // generous ceiling; the package itself is hard-capped at 64 KiB

// ── build + gate + report ─────────────────────────────────────────────────────
const state = { lastReport: null, lastBuild: null, lastGraph: null, lastShareCode: null, lastHash: null };
let hashSeq = 0; // guards async fingerprint writes against rapid rebuilds
let freeSandboxEditor = null; // lazily mounted Free Sandbox editor controller (Creator Freedom v1)

// Local DRAFT retention (host-only, NEVER part of the package): the builder remembers your last control
// state on THIS device so you can return and keep going. localStorage lives on the trusted host page only —
// it is never read by the generated game (the importer's source scan bans storage in package code) and is
// never written into the manifest/files. Cleared by "Start fresh".
const DRAFT_KEY = 'cf_builder_draft_v1';
function saveDraft(params) { try { localStorage.setItem(DRAFT_KEY, JSON.stringify({ v: 1, params })); } catch { /* storage blocked → simply no draft */ } }
function loadDraft() {
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    if (!raw) return null;
    const o = JSON.parse(raw);
    return (o && o.v === 1 && o.params && typeof o.params === 'object') ? o.params : null;
  } catch { return null; }
}
function clearDraft() { try { localStorage.removeItem(DRAFT_KEY); } catch { /* no-op */ } }

function currentParams() {
  return {
    builder_mode: el('builderMode')?.value || 'preset',
    package_id: String(el('packageId').value || ''),
    display_name: String(el('displayName').value || ''),
    variant: el('variant').value, accent: el('accent').value, speed: el('speed').value,
    difficulty: el('difficulty').value, motion: el('motion').value,
    juice: el('juice').value, input_mode: el('inputMode').value,
    frame: el('frame').value, budget: Number(el('budget').value) || SIZE_BUDGET_MIN_BYTES,
    rl_lane_count: Number(el('rlLaneCount')?.value) || 3,
    rl_spawn_cadence_ms: Number(el('rlSpawnCadence')?.value) || 650,
    rl_hit_window_ms: Number(el('rlHitWindow')?.value) || 180,
    rl_target_count: Number(el('rlTargetCount')?.value) || 16,
    rl_combo_cap: Number(el('rlComboCap')?.value) || 5,
    rl_miss_limit: Number(el('rlMissLimit')?.value) || 5,
    rl_difficulty_ramp: el('rlDifficultyRamp')?.value || 'gentle',
    rl_particle_effects: el('rlParticles')?.value || 'soft',
    rl_screen_shake: el('rlShake')?.value || 'soft',
    rl_contrast: el('rlContrast')?.value || 'high',
    rl_mobile_controls: el('rlMobileControls')?.value || 'tap_or_swipe_lanes',
  };
}

/** Restore CLOSED controls from a params object — unknown values fall back to defaults; refresh re-gates. */
function applyParams(p) {
  if (!p || typeof p !== 'object') return;
  if (p.builder_mode === 'reaction_lane' || p.builder_mode === 'preset') el('builderMode').value = p.builder_mode;
  if (typeof p.package_id === 'string') el('packageId').value = p.package_id.slice(0, 48);
  if (typeof p.display_name === 'string') el('displayName').value = p.display_name.slice(0, 40);
  if (VARIANTS.includes(p.variant)) el('variant').value = p.variant;
  if (p.accent in ACCENTS) el('accent').value = p.accent;
  if (p.speed in SPEEDS) el('speed').value = p.speed;
  if (p.difficulty in DIFFICULTY) el('difficulty').value = p.difficulty;
  if (p.motion in MOTION) el('motion').value = p.motion;
  if (p.juice in JUICE) el('juice').value = p.juice;
  if (INPUT_MODES.includes(p.input_mode)) el('inputMode').value = p.input_mode;
  if (FRAME_CONTRACTS.includes(p.frame)) el('frame').value = p.frame;
  const b = Number(p.budget);
  if (Number.isInteger(b) && b >= SIZE_BUDGET_MIN_BYTES && b <= SIZE_BUDGET_MAX_BYTES) el('budget').value = String(b);
  setIfClosed('rlLaneCount', p.rl_lane_count, LANE_COUNTS);
  setIfClosed('rlSpawnCadence', p.rl_spawn_cadence_ms, SPAWN_CADENCE_MS);
  setIfClosed('rlHitWindow', p.rl_hit_window_ms, HIT_WINDOW_MS);
  setIfClosed('rlTargetCount', p.rl_target_count, TARGET_COUNTS);
  setIfClosed('rlComboCap', p.rl_combo_cap, COMBO_CAPS);
  setIfClosed('rlMissLimit', p.rl_miss_limit, MISS_LIMITS);
  setIfClosed('rlDifficultyRamp', p.rl_difficulty_ramp, DIFFICULTY_RAMPS);
  setIfClosed('rlParticles', p.rl_particle_effects, PARTICLE_EFFECTS);
  setIfClosed('rlShake', p.rl_screen_shake, SCREEN_SHAKE);
  setIfClosed('rlContrast', p.rl_contrast, CONTRAST);
  setIfClosed('rlMobileControls', p.rl_mobile_controls, MOBILE_CONTROLS);
  updateModePanels();
  refresh();
}

function setIfClosed(id, value, allowed) {
  const target = el(id);
  if (target && allowed.includes(value)) target.value = String(value);
}

function reactionLaneGraphFromParams(p) {
  const contrast = CONTRAST.includes(p.rl_contrast) ? p.rl_contrast : 'high';
  const mobile = MOBILE_CONTROLS.includes(p.rl_mobile_controls) ? p.rl_mobile_controls : 'tap_or_swipe_lanes';
  return defaultReactionLaneGraph({
    package_id: p.package_id,
    display_name: p.display_name.trim() || 'Reaction Lane Demo',
    frame_contract_id: p.frame,
    rules: {
      objective: { target_count: p.rl_target_count },
      input: { grammar: mobile },
      scoring: { combo_cap: p.rl_combo_cap },
      timer: { spawn_cadence_ms: p.rl_spawn_cadence_ms, hit_window_ms: p.rl_hit_window_ms, difficulty_ramp: p.rl_difficulty_ramp },
      fail: { miss_limit: p.rl_miss_limit },
    },
    layout: { frame: p.frame, lane_count: p.rl_lane_count },
    visuals: {
      palette: p.accent,
      particle_effects: p.rl_particle_effects,
      screen_shake: p.rl_screen_shake,
      contrast,
    },
    accessibility: { contrast, mobile_controls: mobile },
    size_budget_bytes: Number.isInteger(p.budget) ? p.budget : SIZE_BUDGET_MIN_BYTES,
  });
}

function build() {
  const p = currentParams();
  if (p.builder_mode === 'reaction_lane') {
    return buildReactionLanePackage(reactionLaneGraphFromParams(p));
  }
  return buildPackage({
    ...p,
    display_name: p.display_name.trim() || 'Untitled Cabinet',
    budget: Number.isInteger(p.budget) ? p.budget : SIZE_BUDGET_MIN_BYTES,
  });
}

function drawFramePreview(report, buildOut) {
  const canvas = el('framePreview');
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#05060c'; ctx.fillRect(0, 0, canvas.width, canvas.height);
  const dims = report.frame_dims || FRAME_CONTRACT_DIMS[buildOut.manifest.frame_contract_id];
  if (!dims) return;
  const scale = Math.min((canvas.width - 24) / dims.width, (canvas.height - 24) / dims.height);
  const w = dims.width * scale, h = dims.height * scale;
  const x = (canvas.width - w) / 2, y = (canvas.height - h) / 2;
  const accent = ACCENTS[el('accent').value] || ACCENTS.cyan;
  ctx.strokeStyle = accent; ctx.lineWidth = 2; ctx.strokeRect(x, y, w, h);
  ctx.fillStyle = accent; ctx.font = '11px monospace'; ctx.textAlign = 'center';
  ctx.fillText(`${dims.width}×${dims.height} · ${buildOut.variant || buildOut.template}`, canvas.width / 2, y + h + 14);
}

/** Starter METADATA preview — static closed copy from the library (textContent only). */
function renderStarterMeta(starterId) {
  const meta = el('starterMeta');
  if (!meta) return;
  meta.textContent = '';
  const s = getStarter(starterId);
  if (!s) { meta.hidden = true; return; }
  meta.hidden = false;
  const line = (cls, text) => {
    const d = document.createElement('div'); d.className = cls; d.textContent = text; meta.appendChild(d);
  };
  line('sm-pitch', s.pitch);
  line('sm-explain', s.explain);
  line('sm-tags', `${s.tags.join(' · ')} · ~${s.round_s}s rounds · ${s.params.input_mode}`);
  line('sm-note', INPUT_MODE_COPY[s.params.input_mode] || '');
  line('sm-note', s.result_note);
  line('sm-note', `Mobile: ${s.mobile_note}`);
  line('sm-note', `Reduced motion: ${s.reduced_motion_note}`);
}

function refresh() {
  if (el('builderMode').value === 'free_sandbox') return; // the Free Sandbox editor self-manages its own build/gate/preview
  const out = build();
  state.lastBuild = out;
  state.lastGraph = out.rule_graph || null;
  const report = importArcadePackage({ manifest: out.manifest, files: out.files });
  const graphErrors = out.graphValidation?.errors || [];
  state.lastReport = graphErrors.length ? { ...report, ok: false, errors: [...graphErrors, ...report.errors] } : report;
  const verdict = el('verdict');
  verdict.textContent = state.lastReport.ok ? 'VALID (untrusted local proposal)' : 'BLOCKED';
  verdict.className = 'verdict ' + (state.lastReport.ok ? 'v-ok' : 'v-bad');
  el('issues').textContent = state.lastReport.errors.length
    ? explainIssues(state.lastReport.errors).map(({ error, hint }) => (hint ? `${error}\n  → ${hint}` : error)).join('\n')
    : '(none)';
  el('sizes').textContent = `${report.limits.total_bytes} / ${report.limits.size_budget_bytes} bytes · trust=${report.result_trust}`;
  el('exportAll').disabled = !state.lastReport.ok;
  el('exportBundle').disabled = !state.lastReport.ok;
  el('testInSandbox').disabled = !state.lastReport.ok;
  // CR1D: the local Share-locally panel exists only for a VALID build.
  const sharePanel = el('sharePanel');
  if (sharePanel) sharePanel.hidden = !state.lastReport.ok;
  if (state.lastReport.ok) {
    updateShareArtifacts(out);
  } else {
    state.lastShareCode = null; state.lastHash = null;
    const ta = el('shareCode'); if (ta) ta.value = '';
    const hEl = el('packageHash'); if (hEl) hEl.textContent = '—';
  }
  saveDraft(currentParams()); // host-only local retention (never part of the package)
  el('srcView').textContent = out.files['game.mjs'];
  el('graphView').textContent = out.rule_graph ? JSON.stringify(out.rule_graph, null, 2) : '(preset builder: no rule graph)';
  drawFramePreview(report, out);
}

function download(name, text, type) {
  const blob = new Blob([text], { type: type || 'text/javascript' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  URL.revokeObjectURL(a.href);
}

/** UTF-8-safe base64 (chunked so a ~64 KiB package never blows the call stack). Dependency-free. */
function toBase64Utf8(str) {
  const bytes = new TextEncoder().encode(str);
  let bin = '';
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  return btoa(bin);
}

/** Compact LOCAL share code for a gated build: NCLOCAL1:<base64(JSON {manifest, files})>. Returns null if
 *  it would exceed the size ceiling. Pure data — the builder never executes the game. */
function shareCodeFor(build) {
  const code = SHARE_PREFIX + toBase64Utf8(JSON.stringify({ manifest: build.manifest, files: build.files }));
  return code.length <= SHARE_CODE_MAX_CHARS ? code : null;
}

/** Plain-text, copyable summary — closed metadata + the local fingerprint. Never an economy receipt. */
function summaryText(build) {
  const m = build.manifest;
  const p = currentParams();
  const template = p.builder_mode === 'reaction_lane' ? 'reaction_lane' : (p.input_mode || 'tap_window');
  return [
    `Game: ${m.display_name || m.package_id || 'Untitled'}`,
    `Template: ${template}`,
    `Accent: ${p.accent}`,
    `Difficulty: ${p.difficulty}`,
    `Frame: ${m.frame_contract_id}`,
    `Package fingerprint: ${state.lastHash || '(computing…)'}`,
    'Local-only. No tickets. No live publishing.',
  ].join('\n');
}

/** Best-effort clipboard copy with a transient button label; falls back to a manual-copy hint. */
function copyToClipboard(text, btn, restore) {
  const flash = (msg) => { if (btn) { btn.textContent = msg; setTimeout(() => { btn.textContent = restore; }, 1400); } };
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => flash('Copied ✓'), () => flash('Press Ctrl+C'));
      return;
    }
  } catch { /* fall through to manual hint */ }
  flash('Press Ctrl+C');
}

/** Refresh the Share-locally panel for a VALID build: the share code + the async local fingerprint. */
function updateShareArtifacts(build) {
  const code = shareCodeFor(build);
  state.lastShareCode = code;
  const ta = el('shareCode');
  if (ta) { ta.value = code || ''; if (!code) ta.placeholder = 'This build is too large for a share code — use Export files instead.'; }
  const seq = ++hashSeq;
  const hEl = el('packageHash');
  if (hEl) hEl.textContent = '…';
  packageHash({ manifest: build.manifest, files: build.files }).then(
    (h) => { if (seq === hashSeq) { state.lastHash = h; if (hEl) hEl.textContent = h; } },
    () => { if (seq === hashSeq) { state.lastHash = null; if (hEl) hEl.textContent = '(unavailable)'; } },
  );
}

/** Apply a STARTER: parameters + naming from the library; the importer re-gates as always. */
function applyStarter(id) {
  const s = getStarter(id);
  renderStarterMeta(id);
  if (!s) return;
  applyParams({ ...currentParams(), ...s.params, package_id: s.id, display_name: s.name });
}

function updateModePanels() {
  const mode = el('builderMode').value;
  const isReaction = mode === 'reaction_lane';
  const isFree = mode === 'free_sandbox';
  el('presetControls').hidden = isReaction || isFree;
  el('presetTokenControls').hidden = isReaction || isFree;
  el('reactionLaneControls').hidden = !isReaction;
  // Free Sandbox swaps the preset/reaction body for the declarative editor; the mode selector stays visible.
  for (const id of ['presetMeta', 'feelGroup', 'frameGroup', 'actionsGroup', 'builderStatus']) {
    const node = el(id); if (node) node.hidden = isFree;
  }
  if (isFree) { const sp = el('sharePanel'); if (sp) sp.hidden = true; } // refresh() re-gates it when leaving Free mode
  const free = el('freeSandboxRoot');
  if (free) {
    free.hidden = !isFree;
    if (isFree && !freeSandboxEditor) freeSandboxEditor = mountFreeSandboxEditor(free);
  }
}

function addOptions(id, values) {
  for (const v of values) {
    const o = document.createElement('option');
    o.value = String(v);
    o.textContent = String(v);
    el(id).appendChild(o);
  }
}

function wire() {
  for (const id of ['packageId', 'displayName']) el(id).addEventListener('input', refresh);
  for (const id of ['variant', 'accent', 'speed', 'difficulty', 'motion', 'juice', 'inputMode', 'frame', 'budget']) el(id).addEventListener('change', refresh);
  el('builderMode').addEventListener('change', () => { updateModePanels(); refresh(); });
  for (const id of ['rlLaneCount', 'rlSpawnCadence', 'rlHitWindow', 'rlTargetCount', 'rlComboCap', 'rlMissLimit', 'rlDifficultyRamp', 'rlParticles', 'rlShake', 'rlContrast', 'rlMobileControls']) {
    el(id).addEventListener('change', refresh);
  }
  el('exportAll').addEventListener('click', () => {
    if (!state.lastBuild || !state.lastReport?.ok) return;
    const { manifest, files } = state.lastBuild;
    download('manifest.json', JSON.stringify(manifest, null, 2), 'application/json');
    download('game.mjs', files['game.mjs']);
    download('adapter.mjs', files['adapter.mjs']);
  });
  // one-click playtest: stash the gated build same-origin, then open the sandbox (which auto-loads it).
  // No download/upload. The sandbox re-gates + runs in its null-origin iframe — handoff is DATA only.
  el('testInSandbox').addEventListener('click', () => {
    if (!state.lastBuild || !state.lastReport?.ok) return;
    try {
      sessionStorage.setItem(HANDOFF_KEY, JSON.stringify({
        v: 1, manifest: state.lastBuild.manifest, files: state.lastBuild.files,
      }));
    } catch { /* storage blocked/full → navigate anyway; the sandbox simply stays idle */ }
    location.href = '../arcade-sandbox/';
  });
  // starter picker: named presets from the closed library — picking one re-runs the full gate
  el('template').addEventListener('change', () => applyStarter(el('template').value));
  // bundle export: ONE json file carrying params + the gated build (for sharing / re-editing)
  el('exportBundle').addEventListener('click', () => {
    if (!state.lastBuild || !state.lastReport?.ok) return;
    const bundle = {
      schema_version: 1,
      bundle_kind: 'arcade_builder_bundle',
      builder_params: currentParams(),
      rule_graph: state.lastBuild.rule_graph || null,
      graph_validation: state.lastBuild.graphValidation || null,
      manifest: state.lastBuild.manifest,
      files: state.lastBuild.files,
    };
    download(`${bundle.builder_params.package_id || 'cabinet'}.builder.json`, JSON.stringify(bundle, null, 2), 'application/json');
  });
  // bundle import: PARAMS ONLY are restored — bundled manifest/files are deliberately IGNORED
  // (the builder regenerates from closed tables and the importer re-gates; imported source never runs).
  el('importBundle').addEventListener('change', async (e) => {
    const f = e.target.files && e.target.files[0]; if (!f) return;
    try {
      const bundle = JSON.parse(await f.text());
      applyParams(bundle && typeof bundle === 'object' ? bundle.builder_params : null);
    } catch { /* unreadable file → nothing restored; the panel keeps its current state */ }
  });
  // CR1D: copy the LOCAL share code (select the field too, so manual Ctrl+C always works) + a plain summary.
  el('copyShareBtn')?.addEventListener('click', () => {
    const ta = el('shareCode');
    if (!ta || !ta.value) return;
    try { ta.focus(); ta.select(); } catch { /* selection optional */ }
    copyToClipboard(ta.value, el('copyShareBtn'), 'Copy share code');
  });
  el('copySummaryBtn')?.addEventListener('click', () => {
    if (!state.lastBuild || !state.lastReport?.ok) return;
    copyToClipboard(summaryText(state.lastBuild), el('copySummaryBtn'), 'Copy summary');
  });
  // closed select options come from the closed tables — single source of truth
  { const o = document.createElement('option'); o.value = ''; o.textContent = '(custom)'; el('template').appendChild(o); }
  for (const [category, starters] of Object.entries(startersByCategory())) {
    const g = document.createElement('optgroup'); g.label = category;
    for (const s of starters) { const o = document.createElement('option'); o.value = s.id; o.textContent = s.name; g.appendChild(o); }
    el('template').appendChild(g);
  }
  for (const v of VARIANTS) { const o = document.createElement('option'); o.value = v; o.textContent = v; el('variant').appendChild(o); }
  for (const k of Object.keys(ACCENTS)) { const o = document.createElement('option'); o.value = k; o.textContent = k; el('accent').appendChild(o); }
  for (const k of Object.keys(SPEEDS)) { const o = document.createElement('option'); o.value = k; o.textContent = k; el('speed').appendChild(o); }
  for (const k of Object.keys(DIFFICULTY)) { const o = document.createElement('option'); o.value = k; o.textContent = k; el('difficulty').appendChild(o); }
  for (const k of Object.keys(MOTION)) { const o = document.createElement('option'); o.value = k; o.textContent = k; el('motion').appendChild(o); }
  for (const k of Object.keys(JUICE)) { const o = document.createElement('option'); o.value = k; o.textContent = k; el('juice').appendChild(o); }
  for (const m of INPUT_MODES) { const o = document.createElement('option'); o.value = m; o.textContent = m; el('inputMode').appendChild(o); }
  for (const f of FRAME_CONTRACTS) { const o = document.createElement('option'); o.value = f; o.textContent = f; el('frame').appendChild(o); }
  addOptions('rlLaneCount', LANE_COUNTS);
  addOptions('rlSpawnCadence', SPAWN_CADENCE_MS);
  addOptions('rlHitWindow', HIT_WINDOW_MS);
  addOptions('rlTargetCount', TARGET_COUNTS);
  addOptions('rlComboCap', COMBO_CAPS);
  addOptions('rlMissLimit', MISS_LIMITS);
  addOptions('rlDifficultyRamp', DIFFICULTY_RAMPS);
  addOptions('rlParticles', PARTICLE_EFFECTS);
  addOptions('rlShake', SCREEN_SHAKE);
  addOptions('rlContrast', CONTRAST);
  addOptions('rlMobileControls', MOBILE_CONTROLS);
  el('speed').value = 'medium';
  el('difficulty').value = 'standard';
  el('motion').value = 'standard';
  el('juice').value = 'standard';
  el('inputMode').value = 'tap_window';
  el('rlLaneCount').value = '3';
  el('rlSpawnCadence').value = '650';
  el('rlHitWindow').value = '180';
  el('rlTargetCount').value = '16';
  el('rlComboCap').value = '5';
  el('rlMissLimit').value = '5';
  el('rlDifficultyRamp').value = 'gentle';
  el('rlParticles').value = 'soft';
  el('rlShake').value = 'soft';
  el('rlContrast').value = 'high';
  el('rlMobileControls').value = 'tap_or_swipe_lanes';
  updateModePanels();
  renderStarterMeta('');
  // Local retention: restore the last on-device draft (if any) and offer "Start fresh".
  const __draft = loadDraft();
  if (__draft) { applyParams(__draft); const dn = el('draftNote'); if (dn) dn.hidden = false; }
  el('clearDraftBtn')?.addEventListener('click', () => { clearDraft(); try { location.reload(); } catch { /* no-op */ } });
  refresh();
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire); else wire();

// ── test/automation hook (mirrors the other CF tools) ────────────────────────
window.__cf_builder = {
  get lastReport() { return state.lastReport; },
  get lastBuild() { return state.lastBuild; },
  get lastGraph() { return state.lastGraph; },
  get starterCount() { return STARTERS.length; },
  refresh,
  currentParams,
  applyParams,
  applyStarter,
};
